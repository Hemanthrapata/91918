let textElement = document.getElementById("message");
let saveButton = document.getElementById("saveButton");

saveButton.onclick = function() {
    let userEnteredText = textElement.value;
    localStorage.setItem("userEnteredText", userEnteredText);

};
let storeduserInputvalue = localStorage.getItem("userEnteredText");

if (storeduserInputvalue === null) {
    textElement = "";
} else {
    textElement.value = storeduserInputvalue;
}